package mk.ukim.finki.wp.lab.web.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet
public class CoursesListServlet extends HttpServlet {
}
