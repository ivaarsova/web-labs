package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.Student;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Repository
public class StudentRepository {

    public static List<Student> students= new ArrayList<>();

    @PostConstruct
    public void init(){
        students.add(new Student("username1","pass1","Name1","Surname1"));
        students.add(new Student("username2","pass2","Name2","Surname2"));
        students.add(new Student("username3","pass3","Name3","Surname3"));
        students.add(new Student("username4","pass4","Name4","Surname4"));
        students.add(new Student("username5","pass5","Name5","Surname5"));
    }
    public List<Student> findAllStudents(){
        return students;
    }


    public List<Student> findAllbyNameOrSurname(String text){
       return students.stream().filter(r->r.getName().equals(text) || r.getSurname().equals(text));
    }
}
