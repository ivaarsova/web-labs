package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.service.StudentService;
import mk.ukim.finki.wp.lab.repository.CourseRepository;

public interface CourseService {
    List<Student> listStudentsByCourse(Long courseId);
    Course addStudentInCourse(String username, Long courseId);
}
