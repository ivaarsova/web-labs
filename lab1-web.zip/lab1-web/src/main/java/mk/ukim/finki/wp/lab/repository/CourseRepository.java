package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.Course;

import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CourseRepository {
    public static List<Course> courses= new ArrayList<>();

    @PostConstruct
    public void init(){
        courses.add(new Course(00001,"course1","desc1"));
        courses.add(new Course(00002,"course2","desc2"));
        courses.add(new Course(00003,"course3","desc3"));
        courses.add(new Course(00004,"course4","desc4"));
        courses.add(new Course(00005,"course5","desc5"));
    }

    public List<Course> findAllCourses() {
        return courses;
    }
    public static Course findById(Long courseId){
        return courses.stream().filter(r->r.getCourseId().equals(courseId));
    }
}
